import torch
from torch import nn
from tiny_optimizedSD.quant_scripts.brecq_quant_layer import UniformAffineQuantizer, round_ste

class FloorWithGradient(torch.autograd.Function):
    @staticmethod
    def forward(ctx, x):
        return x.floor()
    @staticmethod
    def backward(ctx, g):
        return g
    
class AdaRoundQuantizer(nn.Module):
    """
    Adaptive Rounding Quantizer, used to optimize the rounding policy
    by reconstructing the intermediate output.
    Based on
     Up or Down? Adaptive Rounding for Post-Training Quantization: https://arxiv.org/abs/2004.10568

    :param uaq: UniformAffineQuantizer, used to initialize quantization parameters in this quantizer
    :param round_mode: controls the forward pass in this quantizer
    :param weight_tensor: initialize alpha
    """

    def __init__(self, uaq: UniformAffineQuantizer, weight_tensor: torch.Tensor, round_mode='learned_round_sigmoid'):
        super(AdaRoundQuantizer, self).__init__()
        # copying all attributes from UniformAffineQuantizer
        self.n_bits = uaq.n_bits
        self.sym = uaq.sym
        self.delta = uaq.delta
        self.zero_point = uaq.zero_point
        self.n_levels = uaq.n_levels

        self.round_mode = round_mode
        self.alpha = None
        self.soft_targets = False

        # params for sigmoid function
        self.gamma, self.zeta = -0.1, 1.1
        self.beta = 2/3
        self.init_alpha(x=weight_tensor.clone()) 

    def forward(self, x):
        if self.round_mode == 'nearest':
            x_int = torch.round(x / self.delta)
        elif self.round_mode == 'nearest_ste':
            x_int = round_ste(x / self.delta)
        elif self.round_mode == 'stochastic':
            x_floor = torch.floor(x / self.delta)
            rest = (x / self.delta) - x_floor  # rest of rounding
            x_int = x_floor + torch.bernoulli(rest)
            print('Draw stochastic sample')
        elif self.round_mode == 'learned_hard_sigmoid':
            x_floor = torch.floor(x / self.delta)
            if self.soft_targets:
                x_int = x_floor + self.get_soft_targets()
            else:
                x_int = x_floor + (self.alpha >= 0).float()
        else:
            raise ValueError('Wrong rounding mode')

        x_quant = torch.clamp(x_int + self.zero_point, 0, self.n_levels - 1)
        x_float_q = (x_quant - self.zero_point) * self.delta

        return x_float_q

    def get_soft_targets(self):
        return torch.clamp(torch.sigmoid(self.alpha) * (self.zeta - self.gamma) + self.gamma, 0, 1)

    def init_alpha(self, x: torch.Tensor):
        x_floor = torch.floor(x / self.delta)
        if self.round_mode == 'learned_hard_sigmoid':
            print('Init alpha to be FP32')
            rest = (x / self.delta) - x_floor  # rest of rounding [0, 1)
            alpha = -torch.log((self.zeta - self.gamma) / (rest - self.gamma) - 1)  # => sigmoid(alpha) = rest
            self.alpha = nn.Parameter(alpha)
        else:
            raise NotImplementedError

class SimpleDequantizer(nn.Module):
    """
    Adaptive Rounding Quantizer, used to optimize the rounding policy
    by reconstructing the intermediate output.
    Based on
     Up or Down? Adaptive Rounding for Post-Training Quantization: https://arxiv.org/abs/2004.10568

    :param uaq: UniformAffineQuantizer, used to initialize quantization parameters in this quantizer
    :param round_mode: controls the forward pass in this quantizer
    :param weight_tensor: initialize alpha
    """

    def __init__(self, uaq: UniformAffineQuantizer, weight):
        super(SimpleDequantizer, self).__init__()
        # copying all attributes from UniformAffineQuantizer
        # self.n_bits = uaq.n_bits
        self.n_bits = torch.tensor(uaq.n_bits, dtype=torch.int8)
        self.sym = uaq.sym
        # self.delta = uaq.delta
        # self.zero_point = uaq.zero_point
        self.n_levels = uaq.n_levels
        self.ori_shape = weight.shape

        if len(weight.shape) == 4:
            self.delta = nn.Parameter(torch.randn(size=(weight.shape[0]*4, 1, 1, 1)), requires_grad=False)
            self.zero_point = nn.Parameter(torch.randn(size=(weight.shape[0]*4, 1, 1, 1)), requires_grad=False)
        elif len(weight.shape) == 2:
            self.delta = nn.Parameter(torch.randn(size=(weight.shape[0]*4, 1)), requires_grad=False)
            self.zero_point = nn.Parameter(torch.randn(size=(weight.shape[0]*4, 1)), requires_grad=False)
        else:
            print(weight.shape)
            raise ValueError('shape not implemented')
        
        # params for sigmoid function
        self.gamma, self.zeta = -0.1, 1.1
        self.beta = 2/3

        self.gap = torch.tensor(list(range(0, 8, self.n_bits)), dtype=torch.uint8).unsqueeze(0)

    def forward(self, x_int2_pack8):
        ## unpack
        if len(x_int2_pack8.shape) == 4:
            x_int2_pack8 = x_int2_pack8.flatten(1)

        weight = torch.bitwise_right_shift(torch.unsqueeze(x_int2_pack8, 1).expand(-1, 8 // self.n_bits, -1), self.gap.to(x_int2_pack8.device).unsqueeze(-1)).to(torch.int8)
        weight = torch.bitwise_and(weight,(2 ** self.n_bits) - 1)
        weight = weight.reshape(-1, weight.shape[2])
        weight = weight.reshape([self.ori_shape[0]*4]+list(self.ori_shape[1:]))

        x_float_q = (weight - self.zero_point) * self.delta

        return x_float_q